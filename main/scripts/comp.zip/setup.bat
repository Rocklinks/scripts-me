@echo off
setlocal enabledelayedexpansion

echo ============================================================
echo  Portable Python Setup for Branch Companion
echo ============================================================
echo.

set SCRIPT_DIR=%~dp0
set PYTHON_DIR=%SCRIPT_DIR%python
set PYTHON_ZIP=%SCRIPT_DIR%python-embed.zip
set PYTHON_URL=https://www.python.org/ftp/python/3.12.4/python-3.12.4-embed-amd64.zip
set GET_PIP_URL=https://bootstrap.pypa.io/get-pip.py

REM ============================================================
REM Step 1: Download Python Embeddable Package
REM ============================================================

if exist "%PYTHON_DIR%\python.exe" (
    echo [OK] Python already installed.
    goto :install_packages
)

echo [1/4] Downloading Python 3.12.4 (embeddable, ~10MB)...
powershell -NoProfile -Command ^
    "Invoke-WebRequest -Uri '%PYTHON_URL%' -OutFile '%PYTHON_ZIP%'"

if not exist "%PYTHON_ZIP%" (
    echo [ERROR] Download failed! Check your internet connection.
    pause
    exit /b 1
)

echo [2/4] Extracting Python...
mkdir "%PYTHON_DIR%" 2>nul
powershell -NoProfile -Command ^
    "Expand-Archive -Path '%PYTHON_ZIP%' -DestinationPath '%PYTHON_DIR%' -Force"
del "%PYTHON_ZIP%"

REM ============================================================
REM Step 3: Enable pip in embeddable Python
REM ============================================================

echo [3/4] Configuring Python...

REM Uncomment import site in python312._pth
powershell -NoProfile -Command ^
    "$pth = Get-Content '%PYTHON_DIR%\python312._pth' -Raw; ^
     $pth = $pth -replace '#import site', 'import site'; ^
     Set-Content '%PYTHON_DIR%\python312._pth' $pth"

REM Download get-pip.py
powershell -NoProfile -Command ^
    "Invoke-WebRequest -Uri '%GET_PIP_URL%' -OutFile '%SCRIPT_DIR%get-pip.py'"

REM Install pip
"%PYTHON_DIR%\python.exe" "%SCRIPT_DIR%get-pip.py" --no-warn-script-location
del "%SCRIPT_DIR%get-pip.py" 2>nul

REM ============================================================
REM Step 4: Install required packages
REM ============================================================

:install_packages
echo [4/4] Installing required packages (openpyxl, lxml)...
"%PYTHON_DIR%\python.exe" -m pip install openpyxl lxml --no-warn-script-location --quiet

if errorlevel 1 (
    echo.
    echo [ERROR] Package installation failed!
    pause
    exit /b 1
)

echo.
echo ============================================================
echo  Setup Complete!
echo ============================================================
echo.
echo  You can now run comp.bat to use Branch Companion.
echo.
pause
