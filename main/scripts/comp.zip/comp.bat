@echo off
setlocal enabledelayedexpansion

set SCRIPT_DIR=%~dp0
set PYTHON=%SCRIPT_DIR%python\python.exe

REM ============================================================
REM Check if portable Python exists
REM ============================================================

if not exist "%PYTHON%" (
    echo.
    echo [ERROR] Portable Python not found!
    echo.
    echo Please run setup.bat first to download and install Python.
    echo.
    pause
    exit /b 1
)

REM ============================================================
REM Part 1: Absent Manager Detection (PowerShell, NO Python)
REM ============================================================

if "%~1"=="" (
    powershell -NoProfile -Command ^
    "$csvFiles = Get-ChildItem -Filter '*.csv' | Sort-Object Name; ^
     $count = 0; ^
     $lines = @('Today App not loggedin managers'); ^
     foreach ($f in $csvFiles) { ^
         $branch = $f.BaseName; ^
         $content = Get-Content $f.FullName; ^
         $headers = $content[0] -split ','; ^
         $weekIndices = @(); ^
         for ($i = 0; $i -lt $headers.Count; $i++) { ^
             if ($headers[$i] -match 'week') { $weekIndices += $i } ^
         } ^
         for ($r = 1; $r -lt $content.Count; $r++) { ^
             $fields = $content[$r] -split ','; ^
             if ($fields.Count -gt 1 -and $fields[1] -match 'branch manager') { ^
                 $lastOx = $null; ^
                 foreach ($idx in $weekIndices) { ^
                     if ($idx -lt $fields.Count) { ^
                         $val = $fields[$idx]; ^
                         if ($val -notmatch '^[-]+$') { ^
                             for ($j = $val.Length - 1; $j -ge 0; $j--) { ^
                                 if ($val[$j] -eq 'O' -or $val[$j] -eq 'X') { ^
                                     $lastOx = $val[$j]; break ^
                                 } ^
                             } ^
                         } ^
                     } ^
                 } ^
                 if ($lastOx -eq 'O') { ^
                     $count++; ^
                     $lines += \"$count. $branch\" ^
                 } ^
                 break ^
             } ^
         } ^
     } ^
     $lines | Out-File -FilePath '1.txt' -Encoding UTF8; ^
     Write-Host \"Absent managers written to 1.txt ($count found)\""
) else (
    if not exist "%~1" (
        echo File not found: %~1
        exit /b 1
    )
    powershell -NoProfile -Command ^
    "$f = Get-Item '%~1'; ^
     $branch = $f.BaseName; ^
     $content = Get-Content $f.FullName; ^
     $headers = $content[0] -split ','; ^
     $weekIndices = @(); ^
     for ($i = 0; $i -lt $headers.Count; $i++) { ^
         if ($headers[$i] -match 'week') { $weekIndices += $i } ^
     } ^
     $count = 0; ^
     $lines = @('Today App not loggedin managers'); ^
     for ($r = 1; $r -lt $content.Count; $r++) { ^
         $fields = $content[$r] -split ','; ^
         if ($fields.Count -gt 1 -and $fields[1] -match 'branch manager') { ^
             $lastOx = $null; ^
             foreach ($idx in $weekIndices) { ^
                 if ($idx -lt $fields.Count) { ^
                     $val = $fields[$idx]; ^
                     if ($val -notmatch '^[-]+$') { ^
                         for ($j = $val.Length - 1; $j -ge 0; $j--) { ^
                             if ($val[$j] -eq 'O' -or $val[$j] -eq 'X') { ^
                                 $lastOx = $val[$j]; break ^
                             } ^
                         } ^
                     } ^
                 } ^
             } ^
             if ($lastOx -eq 'O') { ^
                 $count++; ^
                 $lines += \"$count. $branch\" ^
             } ^
             break ^
         } ^
     } ^
     $lines | Out-File -FilePath '1.txt' -Encoding UTF8; ^
     Write-Host \"Absent managers written to 1.txt ($count found)\""
)

REM ============================================================
REM Part 2: Excel Generation (Portable Python)
REM ============================================================

if "%~1"=="" (
    "%PYTHON%" "%SCRIPT_DIR%_comp_excel.py" *.csv All_Branch_Companion.xlsx
) else (
    "%PYTHON%" "%SCRIPT_DIR%_comp_excel.py" "%~1" "%~n1.xlsx"
)

echo Done.
pause
