# Branch Companion - Windows

## Quick Start

### First Time Setup (one-time only):
1. Double-click `setup.bat`
2. Wait for download and installation (~30 seconds)
3. Done!

### Daily Usage:
1. Place CSV files in this folder
2. Double-click `comp.bat`
3. Check `1.txt` for absent managers
4. Check Excel file for detailed report

## Files

| File | Description |
|------|-------------|
| `comp.bat` | Main script - run this daily |
| `setup.bat` | One-time setup - downloads Python |
| `_comp_excel.py` | Python helper for Excel generation |

## What It Does

### 1. Absent Manager Detection (PowerShell)
- Reads all CSV files
- Finds "Branch Manager" row
- Checks last week entry (O = not logged in)
- Writes `1.txt` with absent managers

### 2. Excel Generation (Portable Python)
- Creates styled Excel with colored headers
- Color-codes week entries (O = red, X = green)
- Adds data bars for Login %

## Usage Options

### Process ALL CSV files:
```
comp.bat
```
- Output: `1.txt` + `All_Branch_Companion.xlsx`

### Process SINGLE CSV file:
```
comp.bat Ambasamudram.csv
```
- Output: `1.txt` + `Ambasamudram.xlsx`

## Troubleshooting

### "Portable Python not found" error
- Run `setup.bat` first to install Python

### Download fails during setup
- Check internet connection
- Try again - it downloads Python 3.12.4 (~10MB)

### Excel not generated
- Ensure CSV files are in the same folder as `comp.bat`
- Check that Python packages are installed (run `setup.bat` again)
